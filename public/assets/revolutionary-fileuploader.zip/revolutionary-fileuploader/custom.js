$(document).ready(function() {

	// enable fileuploader plugin
	$('.file').fileuploader({
        addMore: true
    });
	// 	$('input[name="files"]').fileuploader({
    //     addMore: true
    // });
	//
});
